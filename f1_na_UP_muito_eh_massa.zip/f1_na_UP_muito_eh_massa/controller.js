let carMax;
let carChar;
let carLewis;
let carGeorge;
let carCarlos;

let startBtn;

let maxPos = 0;
let charPos = 0;
let lewisPos = 0;
let georgePos = 0;
let carlosPos = 0;

let carPositions = [maxPos, charPos, lewisPos, georgePos, carlosPos];

function init(){
    carMax = document.getElementById("MaxVerstappen");
    carChar = document.getElementById("CharlesLeclerc");
    carLewis = document.getElementById("LewisHamilton");
    carGeorge = document.getElementById("GeorgeRussel");
    carCarlos = document.getElementById("CarlosSainzJr");

    startBtn = document.getElementById("startBtn");

    startBtn.addEventListener('click',startRun);
}

function loop(){


        maxPos += Math.random() * 5;
        charPos += Math.random() * 5;
        lewisPos += Math.random() * 5;
        georgePos += Math.random() * 5;
        carlosPos += Math.random() * 5;

        carMax.style.transform = "translateY(" + maxPos + 'px' + ") translateX(20px)";
        carChar.style.transform = "translateY(" + charPos + 'px' + ") translateX(100px)";
        carLewis.style.transform = "translateY(" + lewisPos + 'px' + ") translateX(180px)";
        carGeorge.style.transform = "translateY(" + georgePos + 'px' + ") translateX(260px)";
        carCarlos.style.transform = "translateY(" + carlosPos + 'px' + ") translateX(340px)";

        carPositions[0] = maxPos;
        carPositions[1] = charPos;
        carPositions[2] = lewisPos;
        carPositions[3] = georgePos;
        carPositions[4] = carlosPos;

        for (let index = 0; index < carPositions.length; index++) {

            const position = carPositions[index];
            if (position > 570) {
                clearInterval(loop);
            }
        }
    }
    
    function startRun(){
        setInterval(loop, 50);
    }