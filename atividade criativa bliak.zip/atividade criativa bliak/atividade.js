document.addEventListener('DOMContentLoaded', function() {
    const wrapper = document.querySelector('.wrapper');
    const question = document.querySelector('.question');
    const yesBtn = document.getElementById('yes-btn');
    const noBtn = document.getElementById('no-btn');

    let wrapperRect = wrapper.getBoundingClientRect();
    let noBtnRect = noBtn.getBoundingClientRect();
    let noBtnWidth = noBtn.offsetWidth;
    let noBtnHeight = noBtn.offsetHeight;

    yesBtn.addEventListener('click', () => {
        question.textContent = 'You won';
    });

    noBtn.addEventListener("mouseover", () => {
        wrapperRect = wrapper.getBoundingClientRect(); // Atualiza as dimensões do wrapper
        noBtnRect = noBtn.getBoundingClientRect(); // Atualiza as dimensões do botão

        const i = Math.floor(Math.random() * (wrapperRect.width - noBtnWidth)) + 1;
        const j = Math.floor(Math.random() * (wrapperRect.height - noBtnHeight)) + 1;

        noBtn.style.left = i + 'px';
        noBtn.style.top = j + 'px';
    }, false);
});
