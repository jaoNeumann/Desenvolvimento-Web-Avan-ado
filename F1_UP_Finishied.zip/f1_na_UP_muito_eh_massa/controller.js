let carMax;
let carChar;
let carLewis;
let carGeorge;
let carCarlos;

let startBtn;
let resetBtn;

let maxPos = 0;
let charPos = 0;
let lewisPos = 0;
let georgePos = 0;
let carlosPos = 0;

let carPositions = [maxPos, charPos, lewisPos, georgePos, carlosPos];

let intervalId;
let raceEnded = false;

let winner;
let betCarIndex = -1; 


let credits = 100;


function init(){
    carMax = document.getElementById("MaxVerstappen");
    carChar = document.getElementById("CharlesLeclerc");
    carLewis = document.getElementById("LewisHamilton");
    carGeorge = document.getElementById("GeorgeRussel");
    carCarlos = document.getElementById("CarlosSainzJr");

    startBtn = document.getElementById("startBtn");
    resetBtn = document.getElementById("resetBtn");

    startBtn.addEventListener('click', startRun);
    resetBtn.addEventListener('click', resetCars);

    resetBtn.style.display = "none";
}

function loop() {
    for (let index = 0; index < carPositions.length; index++) {
        const position = carPositions[index];
        if (position >= 500) {
            clearInterval(intervalId);
            if (!raceEnded) {
                raceEnded = true;
                displayWinner(index);
                resetBtn.style.display = "block"; 
            }
            return;
        }
    }

    maxPos += Math.random() * 10;
    charPos += Math.random() * 5;
    lewisPos += Math.random() * 5;
    georgePos += Math.random() * 5;
    carlosPos += Math.random() * 5;

    carMax.style.transform = "translateY(" + maxPos + 'px' + ") translateX(20px)";
    carChar.style.transform = "translateY(" + charPos + 'px' + ") translateX(100px)";
    carLewis.style.transform = "translateY(" + lewisPos + 'px' + ") translateX(180px)";
    carGeorge.style.transform = "translateY(" + georgePos + 'px' + ") translateX(260px)";
    carCarlos.style.transform = "translateY(" + carlosPos + 'px' + ") translateX(340px)";

    carPositions[0] = maxPos;
    carPositions[1] = charPos;
    carPositions[2] = lewisPos;
    carPositions[3] = georgePos;
    carPositions[4] = carlosPos;
}

function startRun() {

    startBtn.disabled = true;
    resetBtn.disabled = true;
    document.getElementById("betSelect").disabled = true;

    betCarIndex = parseInt(document.getElementById("betSelect").value);
    
    if (credits < 5) {
        alert("Você não possui créditos suficientes para fazer uma aposta.");
        return;
    }

    credits -= 5;
    document.getElementById("creditsDisplay").textContent = credits;

    if (!raceEnded) {
        intervalId = setInterval(loop, 50);
        raceEnded = false;
        resetBtn.style.display = "none"; 
    }
}

function displayWinner(index) {
    switch(index) {
        case 0:
            winner = "Max Verstappen";
            break;
        case 1:
            winner = "Charles Leclerc";
            break;
        case 2:
            winner = "Lewis Hamilton";
            break;
        case 3:
            winner = "George Russel";
            break;
        case 4:
            winner = "Carlos Sainz Jr";
            break;
        default:
            winner = "Unknown";
    }

    if (winner !== "Unknown") {
        if (index === betCarIndex) { 
            credits += 10; 
            alert("Congratulations! You won the racing and received US$10.");
        } else {
            alert("You lost the bet. The winner is: " + winner);
        }
    } else {
        alert("Quebrou");
    }

    document.getElementById("creditsDisplay").textContent = credits;

    resetBtn.style.display = "block";

    resetBtn.disabled = false;
    document.getElementById("betSelect").disabled = false;
}

function resetCars() {    
    maxPos = 0;
    charPos = 0;
    lewisPos = 0;
    georgePos = 0;
    carlosPos = 0;

    winner = "Unknown"; 

    carMax.style.transform = "translateY(" + maxPos + 'px' + ") translateX(20px)";
    carChar.style.transform = "translateY(" + charPos + 'px' + ") translateX(100px)";
    carLewis.style.transform = "translateY(" + lewisPos + 'px' + ") translateX(180px)";
    carGeorge.style.transform = "translateY(" + georgePos + 'px' + ") translateX(260px)";
    carCarlos.style.transform = "translateY(" + carlosPos + 'px' + ") translateX(340px)";

    raceEnded = false; 
    resetBtn.style.display = "none"; 

    carPositions[0] = maxPos;
    carPositions[1] = charPos;
    carPositions[2] = lewisPos;
    carPositions[3] = georgePos;
    carPositions[4] = carlosPos;

    clearInterval(intervalId);

    startBtn.disabled = false;
}

