import mongoose, { Schema, Document } from 'mongoose';

// Interface para tipar o modelo Item
export interface IItem extends Document {
  name: string;
  description: string;
  price: number;
}

// Definição do schema
const ItemSchema: Schema = new Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
});

// Criação do modelo
const Item = mongoose.model<IItem>('Item', ItemSchema);

// Exportando o modelo
export default Item;
