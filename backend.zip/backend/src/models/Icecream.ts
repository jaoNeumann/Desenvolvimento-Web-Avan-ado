export interface Icecream {
  _id?: string; // ID gerado automaticamente pelo MongoDB
  flavor: string; // Sabor do sorvete
  description: string; // Descrição do sorvete
}
