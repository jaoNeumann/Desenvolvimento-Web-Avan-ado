import { Icecream } from '../models/Icecream'; // Importe o modelo de dados do sorvete

// Simulando um banco de dados de sorvetes
let icecreams: Icecream[] = [
  { _id: '1', flavor: 'Chocolate', description: 'Delicious chocolate icecream' },
  { _id: '2', flavor: 'Vanilla', description: 'Classic vanilla icecream' }
];

export class IcecreamService {
  
  // Método para obter todos os sorvetes
  public async getAllIcecreams(): Promise<Icecream[]> {
    return icecreams; // Simplesmente retorna a lista de sorvetes
  }

  // Método para obter um sorvete pelo ID
  public async getIcecreamById(id: string): Promise<Icecream | undefined> {
    return icecreams.find(icecream => icecream._id === id); // Retorna o sorvete com o ID correspondente
  }

  // Método para criar um novo sorvete
  public async createIcecream(icecream: Icecream): Promise<void> {
    icecreams.push(icecream); // Adiciona o novo sorvete à lista
  }

  // Método para atualizar um sorvete existente
  public async updateIcecream(updatedIcecream: Icecream): Promise<void> {
    const index = icecreams.findIndex(icecream => icecream._id === updatedIcecream._id); // Encontra o índice do sorvete a ser atualizado
    if (index !== -1) {
      icecreams[index] = updatedIcecream; // Atualiza o sorvete na lista
    }
  }

  // Método para deletar um sorvete pelo ID
  public async deleteIcecream(id: string): Promise<void> {
    icecreams = icecreams.filter(icecream => icecream._id !== id); // Remove o sorvete com o ID correspondente
  }
}
