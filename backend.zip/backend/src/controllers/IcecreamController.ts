import { Controller, Get, Post, Put, Delete } from 'tsoa';

@Controller('/icecreams')
export class IcecreamController {

  @Get('/')
  public async getAllIcecreams(): Promise<any[]> {
    try {
      // Lógica para obter todos os sorvetes
      return [];
    } catch (error) {
      console.error('Erro ao obter sorvetes:', error);
      throw error;
    }
  }

  @Post('/')
  public async createIcecream(): Promise<void> {
    try {
      // Lógica para criar um novo sorvete
    } catch (error) {
      console.error('Erro ao criar sorvete:', error);
      throw error;
    }
  }

  @Put('/')
  public async updateIcecream(): Promise<void> {
    try {
      // Lógica para atualizar um sorvete
    } catch (error) {
      console.error('Erro ao atualizar sorvete:', error);
      throw error;
    }
  }

  @Delete('/')
  public async deleteIcecream(): Promise<void> {
    try {
      // Lógica para deletar um sorvete
    } catch (error) {
      console.error('Erro ao deletar sorvete:', error);
      throw error;
    }
  }
}
