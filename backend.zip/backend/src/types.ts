// src/types.ts
export interface Item {
    _id: string; // Note que é string, não ObjectId
    name: string;
    description: string;
    price: number;
  }
  